﻿using Nancy;

using System.Collections.Generic;

using System.Text;
using System.IO;

using System.Data;
using System.Data.SqlClient;


using Suwen.ToFit.BLL;
using Suwen.ToFit.DM;

using Starock.Tools;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using Nancy.ModelBinding;
using Nancy.Extensions;


namespace ToFit_WebAPI
{
    public class TrainerModule : NancyModule
    {
        public TrainerModule()
        {
            BLL_Trainer oTrainer = new BLL_Trainer();

            //获取教练列表
            Get["Trainer/GetTrainerList/"] = param => 
                {

                    DataTable dtResult = oTrainer.GetTrainerList();


                    return JsonConvert.SerializeObject(dtResult); //Response.AsJson(dtResult);
                };


            //添加问教练的记录
            Post["Trainer/AddAskInfo/"] = param => 
                {

                    DM_Ask dmInfo = this.Bind<DM_Ask>();

                    string result = oTrainer.Ask_Add(dmInfo);

                    return "{\"result\":"+result+"}"; 
                };



            //获取教练列表
            Get["Trainer/GetAskRecord/{userID},{trainerID}"] = param => 
                {

                    List<DM_Ask> listResult = oTrainer.GetAskRecord(param.userid, param.trainerID);


                    if(listResult.Count>0)
                    {
                        return JsonConvert.SerializeObject(listResult); //Response.AsJson(listResult);
                    }
                    else
                    {
                        return "{\"result\":0}"; 
                    }
                };



        }
    }
}

