﻿using Nancy;

using System.Collections.Generic;

using System.Text;


using System.Data;
using System.Data.SqlClient;


using Suwen.ToFit.BLL;
using Suwen.ToFit.DM;

using Starock.Tools;

using Newtonsoft.Json;

using Nancy.ModelBinding;


namespace ToFit_WebAPI
{
	public class LessonModule : NancyModule
	{
		public LessonModule ()
		{
			BLL_LessonNews oNews = new BLL_LessonNews ();
            BLL_LessonVedio oVedio = new BLL_LessonVedio();


			//根据classID获取资讯列表
			Get["/Lesson/GetNewsList/{classID}"] = param =>
			{
				List<DM_News> listNews = oNews.GetNewsList (param.classID);


				return Response.AsJson(listNews);
			};



            Get["/Lesson/Vedio/GetAlbumList/"] = param =>
                {
                    List<DM_LessonVedioAlbum> listResult = oVedio.GetAlbumList();


                    if(listResult.Count>0)
                    {
                        return Response.AsJson(listResult);
                    }
                    else
                    {
                        return "{\"result\":0}"; 
                    }


                };


            Get["/Lesson/Vedio/GetVedioList/{albumID}"] = param =>
                {
                    List<DM_LessonVedio> listResult = oVedio.GetVedioList(param.albumID);


                    if(listResult.Count>0)
                    {
                        return Response.AsJson(listResult);
                    }
                    else
                    {
                        return "{\"result\":0}"; 
                    }


                };









		}
	}
}

